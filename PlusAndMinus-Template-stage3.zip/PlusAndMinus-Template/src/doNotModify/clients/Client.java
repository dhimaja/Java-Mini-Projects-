//DO NOT MODIFY THIS FILE

package doNotModify.clients;

public class Client {

    public static void main(String[] args) {
    	Game game = new Game();
    	game.play();
    }

}
